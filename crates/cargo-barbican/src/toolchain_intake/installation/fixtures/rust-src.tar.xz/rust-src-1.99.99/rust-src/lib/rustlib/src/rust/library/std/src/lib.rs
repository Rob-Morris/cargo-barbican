// Authored non-executable rust-src qualification fixture.
